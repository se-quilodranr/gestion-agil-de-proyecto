document.getElementById('formRegistro').addEventListener('submit', async (e) => {
  e.preventDefault();
  const nombre = document.getElementById('nombreRegistro').value;
  const clave = document.getElementById('claveRegistro').value;

  const res = await fetch('/registro', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ nombre, clave })
  });

  const data = await res.json();
  const msg = document.getElementById('mensajeRegistro');
  msg.textContent = data.mensaje || '¡Registro exitoso!';

  if (data.ok) {
    document.getElementById('registro').classList.add('hidden');
    document.getElementById('login').classList.remove('hidden');
  }
});

document.getElementById('formLogin').addEventListener('submit', async (e) => {
  e.preventDefault();
  const nombre = document.getElementById('nombreLogin').value;
  const clave = document.getElementById('claveLogin').value;

  const res = await fetch('/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ nombre, clave })
  });

  const data = await res.json();
  const msg = document.getElementById('mensajeLogin');
  msg.textContent = data.mensaje || '';

  if (data.ok) {
    document.getElementById('login').classList.add('hidden');
    document.getElementById('bienvenida').classList.remove('hidden');
    cargarInventario();
  }
});

// Inventario ficticio
const items = [
  'Torno mecánico', 'Taladro industrial', 'Sierra cinta', 'Compresor de aire',
  'Soldadora TIG', 'Lijadora de banda', 'Prensa hidráulica', 'Caladora eléctrica',
  'Sierra circular', 'Multímetro industrial'
];

function cargarInventario() {
  const ul = document.getElementById('inventario');
  ul.innerHTML = '';
  items.forEach((nombre, index) => {
    const li = document.createElement('li');
    li.textContent = nombre;

    const btnVender = document.createElement('button');
    btnVender.textContent = 'Vender';
    btnVender.onclick = () => alert(`${nombre} vendido`);

    const btnEliminar = document.createElement('button');
    btnEliminar.textContent = 'Eliminar';
    btnEliminar.onclick = () => {
      items.splice(index, 1);
      cargarInventario();
    };

    li.appendChild(btnVender);
    li.appendChild(btnEliminar);
    ul.appendChild(li);
  });
}
