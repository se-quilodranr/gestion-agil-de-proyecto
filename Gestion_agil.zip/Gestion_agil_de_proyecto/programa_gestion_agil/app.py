from flask import Flask, render_template, request, jsonify
import sqlite3

app = Flask(__name__)

# Crear base de datos
def crear_db():
    conn = sqlite3.connect('usuarios.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS usuarios (
                  nombre TEXT PRIMARY KEY,
                  clave TEXT NOT NULL)''')
    conn.commit()
    conn.close()

crear_db()

@app.route('/')
def inicio():
    return render_template('index.html')

@app.route('/registro', methods=['POST'])
def registrar():
    data = request.get_json()
    nombre = data.get('nombre')
    clave = data.get('clave')

    if not nombre or not clave:
        return jsonify({'ok': False, 'mensaje': 'Completa todos los campos'})

    conn = sqlite3.connect('usuarios.db')
    c = conn.cursor()
    c.execute("SELECT * FROM usuarios WHERE nombre = ?", (nombre,))
    if c.fetchone():
        return jsonify({'ok': False, 'mensaje': 'El usuario ya existe'})

    c.execute("INSERT INTO usuarios (nombre, clave) VALUES (?, ?)", (nombre, clave))
    conn.commit()
    conn.close()
    return jsonify({'ok': True})

@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    nombre = data.get('nombre')
    clave = data.get('clave')

    if not nombre or not clave:
        return jsonify({'ok': False, 'mensaje': 'Completa todos los campos'})

    conn = sqlite3.connect('usuarios.db')
    c = conn.cursor()
    c.execute("SELECT * FROM usuarios WHERE nombre = ? AND clave = ?", (nombre, clave))
    if c.fetchone():
        return jsonify({'ok': True})
    return jsonify({'ok': False, 'mensaje': 'Usuario no encontrado. Regístrate aquí'})

if __name__ == '__main__':
    app.run(debug=True)
